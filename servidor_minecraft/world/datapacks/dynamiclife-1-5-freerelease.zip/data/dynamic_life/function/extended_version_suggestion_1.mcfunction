tellraw @p [{"color":"gold","text":"Thanks so much for trying out the Dynamic Life datapack! If you're enjoying it, you might really like the Extended Dynamic Life version. It adds tons of new species like Birch, Water Lily, Tall Fern, Italian Poplar, Fox Poo, Fungi, and even forest fires! You can find it on my "},{"text":"Patreon (clickable link)","color":"aqua","underlined":true,"click_event":{"action":"open_url","url":"https://patreon.com/DynamicLife"}}]

schedule function dynamic_life:extended_version_suggestion_2 13s
schedule function dynamic_life:extended_version_suggestion_3 26s