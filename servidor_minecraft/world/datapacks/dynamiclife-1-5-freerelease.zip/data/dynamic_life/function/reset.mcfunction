function dynamic_life:kill_everything

advancement revoke @s everything

scoreboard players set $quick_start_ticks number 0
