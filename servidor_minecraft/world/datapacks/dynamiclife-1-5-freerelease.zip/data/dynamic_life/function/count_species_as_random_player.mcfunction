execute at @s store result score $spruce_count rng run execute if entity @e[tag=spruce, distance=..150]
execute at @s store result score $lilac_count rng run execute if entity @e[tag=lilac, distance=..150]
execute at @s store result score $diseased_lilac_count rng run execute if entity @e[tag=diseasedLilac, distance=..150]
execute at @s store result score $grass_count rng run execute if entity @e[tag=grass, distance=..150]
execute at @s store result score $diseased_grass_count rng run execute if entity @e[tag=diseasedGrass, distance=..150]
execute at @s store result score $fox_count rng run execute if entity @e[tag=fox, distance=..150]

# test for enchantments
execute if score $spruce_count rng matches 1.. run advancement grant @s only dynamic_life:spruce
execute if score $lilac_count rng matches 1.. run advancement grant @s only dynamic_life:lilac
execute if score $fox_count rng matches 1.. run advancement grant @s only dynamic_life:fox

execute if score @s messagesSeen matches ..0 if score $spruce_count rng matches 1.. if score $lilac_count rng matches 1.. if score $fox_count rng matches 1.. run function dynamic_life:show_message
