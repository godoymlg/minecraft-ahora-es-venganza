# tag nearby lilacs "infected"
execute at @e[tag=chosen,tag=diseasedLilac] run tag @e[tag=lilac,distance=..4,limit=1] add infected

# place deadbush at infected lilacs
execute at @e[tag=infected,tag=lilac] run setblock ~ ~ ~ dead_bush

# add "diseasedLilac" tag to infected lilacs
tag @e[tag=infected,tag=lilac] add diseasedLilac

# add UE tag from infected lilacs (in case they were sleeping)
tag @e[tag=infected,tag=lilac] remove UEslow
tag @e[tag=infected,tag=lilac] add UE

# remove lilac tag from infected lilacs
tag @e[tag=infected,tag=lilac] remove lilac

# remove "infected" tag from infected diseasedLilacs
tag @e[tag=infected,tag=diseasedLilac] remove infected