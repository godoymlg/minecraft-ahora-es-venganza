execute unless block ~ ~ ~ dead_bush run kill @s[tag=!dormant]

# can infect nearby lilacs
execute if score @s rng matches ..50 run function dynamic_life:diseasedlilac_species/actions/infect_self

# can die
execute if score @s rng matches 51..60 run function dynamic_life:diseasedlilac_species/actions/die_attempt_self

# can become dormant
execute if score @s rng matches 76 run function dynamic_life:diseasedlilac_species/actions/become_dormant_self