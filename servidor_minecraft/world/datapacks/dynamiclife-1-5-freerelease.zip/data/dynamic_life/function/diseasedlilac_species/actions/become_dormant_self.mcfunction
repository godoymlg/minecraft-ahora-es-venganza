# remove all nearby dormant tags (to insure only one dormant lilac exists per area)
tag @e[tag=dormant,tag=diseasedLilac,distance=..35] remove dormant

# add 1 dormant tag to nearby diseasedLilac
tag @e[tag=diseasedLilac,sort=random,limit=1,distance=..35] add dormant