# destroy deadbush at chosen diseasedLilac
fill ~ ~ ~ ~ ~ ~ air replace dead_bush

# kill chosen diseasedLilacs (which are not dormant)
kill @s