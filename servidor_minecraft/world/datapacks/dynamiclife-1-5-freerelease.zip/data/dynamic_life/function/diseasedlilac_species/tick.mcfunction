# can infect nearby lilacs
execute if score $last_random_number rng matches ..50 run function dynamic_life:diseasedlilac_species/actions/infect

# can die
execute if score $last_random_number rng matches 51..60 run function dynamic_life:diseasedlilac_species/actions/die

# can become dormant
execute if score $last_random_number rng matches 76 run function dynamic_life:diseasedlilac_species/actions/become_dormant