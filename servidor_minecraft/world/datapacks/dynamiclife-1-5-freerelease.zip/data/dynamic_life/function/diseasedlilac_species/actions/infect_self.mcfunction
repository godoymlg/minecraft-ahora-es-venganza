# tag nearby lilacs "infected"
execute as @e[tag=lilac,distance=..4,limit=1] at @s run function dynamic_life:lilac_species/lilac/actions/become_infected_self