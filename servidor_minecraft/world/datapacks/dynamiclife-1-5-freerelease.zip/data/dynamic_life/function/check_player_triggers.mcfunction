execute as @a[scores={delay=1..}] run scoreboard players operation global_delay number = @s delay
execute as @a[scores={delay=1..}] run scoreboard players reset @s delay

scoreboard players enable @a delay