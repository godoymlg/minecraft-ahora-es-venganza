# activated in reverse order to prevent instant chaining
# TODO: keep counters of species that update on the occasion. If a species already is counted, don't summon it.


# essential counts
function dynamic_life:count_species_as_random_player






# diseasedLilac create diseasedGrass
execute if score $grass_count rng matches 2000.. if score $diseased_grass_count rng matches ..1 at @e[tag=diseasedLilac, limit=1] run summon marker ~ ~ ~ {Tags:["UE","diseasedGrass","dormant"]}

# lilacs create grasseed
execute if score $lilac_count rng matches 1500.. if score $grass_count rng matches ..5 at @e[tag=lilac, sort=random, limit=10] run summon marker ~ ~ ~ {Tags:["UE","grassSeed"]}

# spruce trees have a rare chance of creating a fox
execute if score $spruce_count rng matches 150.. if score $fox_count rng matches ..5 as @e[tag=spruce, limit=1, distance=..150] at @s positioned ~3 ~ ~ run function dynamic_life:fox_species/fox/actions/summon_named_fox_self

# spruce trees have a rare chance of creating diseasedGrass
execute if score $grass_count rng matches 2000.. if score $diseased_grass_count rng matches ..1 at @e[tag=spruce,sort=random, limit=1] run summon marker ~ ~ ~ {Tags:["UE","diseasedGrass","dormant"]}

# spruce trees have a rare chance of creating diseasedLilac 
execute if score $lilac_count rng matches 2000.. if score $diseased_lilac_count rng matches ..1 at @e[tag=spruce,sort=random, limit=1] run summon marker ~ ~ ~ {Tags:["UE","diseasedLilac","dormant"]}

# spruce trees have a rare chance of creating lilacseeds
execute if score $spruce_count rng matches 100.. if score $lilac_count rng matches ..5 at @e[tag=spruce,limit=50, sort=random] run summon marker ~3 ~ ~ {Tags:["UE","lilacSeed"]}

# players can summon spruce seeds [deprecated, playesr may not want this to happen anymwhere]
#execute if score $last_last_random_number rng matches ..3 at @a run summon minecraft:armor_stand ~ ~ ~ {Tags:["UE","spruceSeed"]}

#tellraw @a [{"text":"Random number: ","color":"gold"},{"score":{"name":"$last_last_random_number","objective":"rng"}}]