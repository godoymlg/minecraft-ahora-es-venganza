# lilacs
execute as @e[tag=lilac, distance=..20] at @s run function dynamic_life:lilac_species/lilac/actions/die_self
kill @e[tag=lilacSeed, distance=..20]
execute as @e[tag=diseasedLilac, distance=..20] at @s run function dynamic_life:diseasedlilac_species/actions/die_self

# grass
execute as @e[tag=grass, distance=..20] at @s run function dynamic_life:grass_species/grass/actions/die_self
kill @e[tag=grassSeed, distance=..20]
execute as @e[tag=diseasedGrass, distance=..20] at @s run function dynamic_life:diseasedgrass_species/actions/die_self


# spruce
execute as @e[tag=spruce, distance=..20] at @s run function dynamic_life:spruce_species/spruce/actions/die_self
kill @e[tag=spruceSeed, distance=..20]

# fox
kill @e[tag=fox, distance=..20]


