execute at @a run tag @e[tag=UE,sort=random,limit=10, distance=..50] add chosen
