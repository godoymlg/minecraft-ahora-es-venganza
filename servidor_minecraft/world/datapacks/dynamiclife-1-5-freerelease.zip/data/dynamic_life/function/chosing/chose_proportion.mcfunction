# Wacky way to get a proportion of entities chosen, no matter how many there are.

execute at @a run tag @e[tag=UE,sort=random,limit=1250,distance=..100] add chosen

execute at @a run tag @e[tag=UE,sort=random,limit=5000,distance=..100] remove chosen

execute at @a run tag @e[tag=UE,sort=random,limit=250,distance=..100] add chosen

execute at @a run tag @e[tag=UE,sort=random,limit=1000,distance=..100] remove chosen

execute at @a run tag @e[tag=UE,sort=random,limit=50,distance=..100] add chosen

execute at @a run tag @e[tag=UE,sort=random,limit=200,distance=..100] remove chosen

execute at @a run tag @e[tag=UE,sort=random,limit=10,distance=..100] add chosen


# slow chosing (only one is chosen)
execute at @a run tag @e[tag=UEslow,sort=random,limit=1,distance=..100] add chosen
