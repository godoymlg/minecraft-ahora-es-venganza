# One tick of dynamic_life, where entities have a chance to update one step.

#execute store result score $doTileDrops number run gamerule doTileDrops
gamerule doTileDrops false

# Prepare random number for all species to use
function dynamic_life:generate_random_number

execute if score $last_random_number rng matches 1 if score $last_random_number rng matches 1 run scoreboard players remove @a messagesSeen 1

# Summon dynamic life potentially
execute if score $last_random_number rng matches 1 run function dynamic_life:summon_dynamic_life/summon_test

# rare species creation 
execute if score $last_random_number rng matches 1 as @r at @s run function dynamic_life:create_species
function dynamic_life:create_species_fast

# Activate species
execute at @a run execute as @e[tag=UE,distance=..130] run function dynamic_life:tick_self
# Activate slow species
execute if score $last_random_number rng matches 99..100 run execute at @a run execute as @e[tag=UEslow,distance=..130] run function dynamic_life:tick_self

gamerule doTileDrops true

# debugging
#execute if score $last_random_number rng matches ..20 run function dynamic_life:temp_show