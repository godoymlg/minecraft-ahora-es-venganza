# Seed can spread
execute if score $last_random_number rng matches ..33 run function dynamic_life:lilac_species/lilacseed/actions/spread

# Seed can die
execute if score $last_random_number rng matches 34..66 run function dynamic_life:lilac_species/lilacseed/actions/die

# Seed can grow
execute if score $last_random_number rng matches 67.. run function dynamic_life:lilac_species/lilacseed/actions/germinate
