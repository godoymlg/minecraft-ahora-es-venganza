# check if not killed by player
execute unless predicate dynamic_life:is_lilac_species run kill @s 

# summon lilacSeed
execute if predicate dynamic_life:is_lilac_species run summon marker ~ ~ ~ {Tags:["lilacSeed","UE"]}

# small chance to go to sleep for performance reasons   #at 2 it realy shrinks down on the time lilacs have to spread in fasttick time, 1 is better
execute if score $last_last_random_number rng matches ..1 if entity @s[tag=produced_once] run function dynamic_life:lilac_species/lilac/actions/go_to_sleep_self

#tag @s[tag=produced_once, tag=!produced_twice] add produced_twice
tag @s[tag=!produced_once] add produced_once