# place lilac 
setblock ~ ~ ~ minecraft:lilac

# add "lilac" tag
tag @s add lilac

# remove "lilacSeed" tag
tag @s remove lilacSeed