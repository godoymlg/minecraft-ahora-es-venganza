# Spread out
execute as @e[tag=chosen,tag=lilacSeed] at @s run function dynamic_life:lilac_species/lilacseed/actions/spread_self