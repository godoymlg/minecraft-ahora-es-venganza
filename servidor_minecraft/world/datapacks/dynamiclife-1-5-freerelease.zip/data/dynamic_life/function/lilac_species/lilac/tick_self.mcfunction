# Lilac can produce seeds        #died out at ..85
execute if score @s rng matches ..86 run function dynamic_life:lilac_species/lilac/actions/produce_seed_self

# Lilac can die
execute if score @s rng matches 87..99 run function dynamic_life:lilac_species/lilac/actions/die_self

# stop lilac nuke
# hopefully nukes are not a problem since all entities have their own individual random number execute if score @s rng matches 100 run function dynamic_life:lilac_species/lilac/actions/stop_lilac_nuke_attempt_self
