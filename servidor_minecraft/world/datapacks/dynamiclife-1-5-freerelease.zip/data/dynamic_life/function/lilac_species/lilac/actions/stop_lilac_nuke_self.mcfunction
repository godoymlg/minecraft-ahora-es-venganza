# kill excess lilac seeds
kill @e[tag=lilacSeed,distance=..2]

# let lilacs die
execute as @e[tag=lilac,distance=..2] at @s run function dynamic_life:lilac_species/lilac/actions/die_self