# summon lilacSeed
execute as @e[tag=chosen,tag=lilac] at @s run function dynamic_life:lilac_species/lilac/actions/produce_seed_self