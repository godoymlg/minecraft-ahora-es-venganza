# Seed can spread
execute if score @s rng matches ..33 at @s run function dynamic_life:lilac_species/lilacseed/actions/spread_self

# Seed can die
execute if score @s rng matches 34..66 run kill @s

# Seed can grow
execute if score @s rng matches 67.. at @s run function dynamic_life:lilac_species/lilacseed/actions/germinate_attempt_self
