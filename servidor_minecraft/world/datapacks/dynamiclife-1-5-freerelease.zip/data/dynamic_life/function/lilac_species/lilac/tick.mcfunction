# Lilac can produce seeds                           #died out at ..85
execute if score $last_random_number rng matches ..86 run function dynamic_life:lilac_species/lilac/actions/produce_seed

# Lilac can die
execute if score $last_random_number rng matches 87..99 run function dynamic_life:lilac_species/lilac/actions/die

# stop lilac nuke
execute if score $last_random_number rng matches 100.. run function dynamic_life:lilac_species/lilac/actions/stop_lilac_nuke
