# if air and grass, germinate
execute if block ~ ~ ~ air if block ~ ~-1 ~ grass_block run function dynamic_life:lilac_species/lilacseed/actions/germinate_self