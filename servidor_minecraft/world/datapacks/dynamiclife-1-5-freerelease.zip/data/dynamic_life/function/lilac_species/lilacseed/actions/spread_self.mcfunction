# Spread out
spreadplayers ~ ~ 0 3.0001 false @s