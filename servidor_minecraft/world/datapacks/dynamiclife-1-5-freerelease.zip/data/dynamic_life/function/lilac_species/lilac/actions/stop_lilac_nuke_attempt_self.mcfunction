#this function is called by 1/100th of lilacs, make it 1/10.000th by generationg a new number
execute store result score @s rng run random value 1..100

execute if score @s rng matches 100 run function dynamic_life:lilac_species/lilac/actions/stop_lilac_nuke_self