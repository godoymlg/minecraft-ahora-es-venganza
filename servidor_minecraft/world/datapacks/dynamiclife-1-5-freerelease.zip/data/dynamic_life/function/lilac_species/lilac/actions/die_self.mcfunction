# Destory flower block
fill ~ ~ ~ ~ ~ ~ air replace lilac

# Kill
kill @s