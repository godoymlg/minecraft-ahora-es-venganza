# place deadbush
fill ~ ~ ~ ~ ~ ~ dead_bush replace lilac

# add "diseasedLilac" tag
tag @s add diseasedLilac

# remove lilac tag
tag @s remove lilac

# add UE tag from infected lilacs (in case they were sleeping)
tag @s remove UEslow
tag @s add UE