function dynamic_life:lilac_species/lilac/tick
function dynamic_life:lilac_species/lilacseed/tick
