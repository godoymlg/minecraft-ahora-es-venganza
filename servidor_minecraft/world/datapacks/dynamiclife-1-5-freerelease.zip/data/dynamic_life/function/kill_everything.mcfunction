# lilacs
execute as @e[tag=lilac] at @s run function dynamic_life:lilac_species/lilac/actions/die_self
kill @e[tag=lilacSeed]
execute as @e[tag=diseasedLilac] at @s run function dynamic_life:diseasedlilac_species/actions/die_self

# grass
execute as @e[tag=grass] at @s run function dynamic_life:grass_species/grass/actions/die_self
kill @e[tag=grassSeed]
execute as @e[tag=diseasedGrass] at @s run function dynamic_life:diseasedgrass_species/actions/die_self


# spruce
execute as @e[tag=spruce] at @s run function dynamic_life:spruce_species/spruce/actions/die_self
kill @e[tag=spruceSeed]

# fox
kill @e[tag=fox]


