# place age4 struct
place template dynamic_life:spruce/spruce_age4_base ~-1 ~ ~-1

# roots
fill ~-1 ~ ~-1 ~-1 ~ ~-1 dark_oak_fence replace air

# nonbase blocks
fill ~-2 ~9 ~0 ~-2 ~9 ~0 spruce_leaves[persistent=true] replace air
fill ~0 ~10 ~2 ~0 ~10 ~2 spruce_leaves[persistent=true] replace air
fill ~1 ~10 ~-2 ~1 ~10 ~-2 spruce_leaves[persistent=true] replace air
fill ~1 ~10 ~2 ~1 ~10 ~2 dark_oak_leaves[persistent=true] replace air
fill ~-3 ~11 ~0 ~-3 ~11 ~0 spruce_leaves[persistent=true] replace air
fill ~-2 ~12 ~-1 ~-2 ~12 ~-1 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~12 ~0 ~-2 ~12 ~0 spruce_leaves[persistent=true] replace air
fill ~-1 ~12 ~-2 ~-1 ~12 ~-2 spruce_leaves[persistent=true] replace air
fill ~0 ~12 ~-3 ~0 ~12 ~-3 dark_oak_leaves[persistent=true] replace air
fill ~1 ~12 ~-3 ~1 ~12 ~-3 spruce_leaves[persistent=true] replace air
fill ~3 ~12 ~0 ~3 ~12 ~0 spruce_leaves[persistent=true] replace air
fill ~-2 ~13 ~1 ~-2 ~13 ~1 spruce_leaves[persistent=true] replace air
fill ~-1 ~13 ~2 ~-1 ~13 ~2 dark_oak_leaves[persistent=true] replace air
fill ~1 ~13 ~-2 ~1 ~13 ~-2 dark_oak_leaves[persistent=true] replace air
fill ~2 ~13 ~-2 ~2 ~13 ~-2 spruce_leaves[persistent=true] replace air
fill ~2 ~13 ~0 ~2 ~13 ~0 dark_oak_leaves[persistent=true] replace air
fill ~0 ~14 ~-2 ~0 ~14 ~-2 spruce_leaves[persistent=true] replace air
fill ~2 ~14 ~1 ~2 ~14 ~1 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~15 ~0 ~-2 ~15 ~0 dark_oak_leaves[persistent=true] replace air
fill ~-1 ~15 ~-2 ~-1 ~15 ~-2 dark_oak_leaves[persistent=true] replace air
fill ~0 ~16 ~2 ~0 ~16 ~2 spruce_leaves[persistent=true] replace air
fill ~2 ~16 ~0 ~2 ~16 ~0 spruce_leaves[persistent=true] replace air
fill ~-2 ~11 ~0 ~-2 ~11 ~0 dark_oak_fence replace spruce_leaves
fill ~2 ~12 ~0 ~2 ~12 ~0 spruce_fence replace dark_oak_leaves

# remove "age3" 
tag @s remove age3

# add "age4"
tag @s add age4