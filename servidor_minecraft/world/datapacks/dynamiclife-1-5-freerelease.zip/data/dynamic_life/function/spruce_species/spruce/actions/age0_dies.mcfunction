kill @e[tag=spruce,tag=chosen,tag=age0]

# don't bother deleting the sapling (fern) so the foxes have something to eat