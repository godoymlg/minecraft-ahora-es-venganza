# check if space above is empty, if so grow
execute at @s[tag=age3] if blocks ~-1 ~18 ~-1 ~1 ~20 ~1 ~ ~100 ~ all run function dynamic_life:spruce_species/spruce/actions/age3_to_age4_self