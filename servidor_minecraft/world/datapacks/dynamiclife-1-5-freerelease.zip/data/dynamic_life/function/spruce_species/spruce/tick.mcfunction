# can produce seed 31%
execute if score $last_random_number rng matches ..31 run function dynamic_life:spruce_species/spruce/actions/produce_seed

# age 0 dies 6%
execute if score $last_random_number rng matches 32..37 run function dynamic_life:spruce_species/spruce/actions/age0_dies

# age 0 can grow to age 1 6%
execute if score $last_random_number rng matches 38..43 run function dynamic_life:spruce_species/spruce/actions/age0_to_age1

# age 1 can grow to age 2 6%
execute if score $last_random_number rng matches 44..49 run function dynamic_life:spruce_species/spruce/actions/age1_to_age2

# age 2 can grow to age 3 6%
execute if score $last_random_number rng matches 50..55 run function dynamic_life:spruce_species/spruce/actions/age2_to_age3

# age 3 can grow to age 4 6%
execute if score $last_random_number rng matches 56..61 run function dynamic_life:spruce_species/spruce/actions/age3_to_age4

# age 4 can grow to age 5 6%
execute if score $last_random_number rng matches 62..67 run function dynamic_life:spruce_species/spruce/actions/age4_to_age5

# age 5 can grow to age 6 6%
execute if score $last_random_number rng matches 68..73 run function dynamic_life:spruce_species/spruce/actions/age5_to_age6

# age 6 can grow to age 7 6%
execute if score $last_random_number rng matches 74..79 run function dynamic_life:spruce_species/spruce/actions/age6_to_age7

# age 7 can grow to age 8 6%
execute if score $last_random_number rng matches 80..85 run function dynamic_life:spruce_species/spruce/actions/age7_to_age8

# age 8 can die 12%
execute if score $last_random_number rng matches 86..98 run function dynamic_life:spruce_species/spruce/actions/age8_to_death
