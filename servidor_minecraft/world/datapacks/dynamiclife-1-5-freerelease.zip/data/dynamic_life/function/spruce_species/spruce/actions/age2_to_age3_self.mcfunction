# place age3 struct
place template dynamic_life:spruce/spruce_age3_base ~-1 ~ ~-1

# roots
fill ~-1 ~ ~ ~-1 ~ ~ dark_oak_wood replace air
fill ~-1 ~-1 ~2 ~-1 ~-1 ~2 dark_oak_wood replace air
fill ~-1 ~-1 ~2 ~-1 ~-1 ~2 spruce_wood replace grass_block

# nonbase blocks
fill ~-3 ~7 ~-1 ~-3 ~7 ~-1 spruce_leaves[persistent=true] replace air
fill ~-2 ~7 ~0 ~-2 ~7 ~0 spruce_leaves[persistent=true] replace air
fill ~-2 ~8 ~-1 ~-2 ~8 ~-1 spruce_leaves[persistent=true] replace dark_oak_leaves
fill ~2 ~8 ~0 ~2 ~8 ~0 spruce_leaves[persistent=true] replace dark_oak_leaves
fill ~0 ~9 ~-2 ~0 ~9 ~-2 spruce_leaves[persistent=true] replace air
fill ~1 ~9 ~2 ~1 ~9 ~2 spruce_leaves[persistent=true] replace air
fill ~-3 ~10 ~1 ~-3 ~10 ~1 spruce_leaves[persistent=true] replace air
fill ~3 ~10 ~0 ~3 ~10 ~0 spruce_leaves[persistent=true] replace air
fill ~-2 ~11 ~0 ~-2 ~11 ~0 spruce_leaves[persistent=true] replace air
fill ~-2 ~11 ~1 ~-2 ~11 ~1 spruce_leaves[persistent=true] replace air
fill ~0 ~11 ~-2 ~0 ~11 ~-2 spruce_leaves[persistent=true] replace air
fill ~0 ~11 ~2 ~0 ~11 ~2 spruce_leaves[persistent=true] replace air
fill ~-2 ~12 ~1 ~-2 ~12 ~1 dark_oak_leaves[persistent=true] replace air
fill ~0 ~12 ~2 ~0 ~12 ~2 dark_oak_leaves[persistent=true] replace air
fill ~2 ~12 ~0 ~2 ~12 ~0 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~7 ~-1 ~-2 ~7 ~-1 dark_oak_fence replace air
fill ~-2 ~10 ~0 ~-2 ~10 ~0 spruce_fence replace spruce_leaves
fill ~2 ~10 ~0 ~2 ~10 ~0 spruce_fence replace air

# remove "age2"
tag @s remove age2

# add "age3"
tag @s add age3