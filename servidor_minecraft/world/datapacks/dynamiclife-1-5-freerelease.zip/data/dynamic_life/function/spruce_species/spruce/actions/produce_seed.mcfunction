# summon UE spruce seed if age >=2
execute at @e[tag=chosen,tag=spruce,tag=!age0,tag=!age1] run summon minecraft:marker ~ ~ ~ {Tags:["UE","born","spruceSeed"]}

# spread seed
execute as @e[tag=spruceSeed,tag=born] at @s run spreadplayers ~ ~ 0 3 false @s

# remove "born" tag from seed
tag @e[tag=born,tag=spruceSeed] remove born