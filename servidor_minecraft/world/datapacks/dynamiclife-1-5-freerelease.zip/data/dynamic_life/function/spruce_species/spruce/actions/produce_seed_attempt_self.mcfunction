# produce seed if age >=2
execute at @s[tag=!age0,tag=!age1] run function dynamic_life:spruce_species/spruce/actions/produce_seed_self