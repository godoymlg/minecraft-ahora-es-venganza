#                                                                                                   did -6
execute as @e[tag=spruceSeed,tag=chosen] at @s run spreadplayers ~ ~ 0 6 false @s