# place age8_air struct
place template dynamic_life:spruce/spruce_age8_air_base ~-1 ~ ~-1

# likely stem blocks will remain
fill ~-2 ~ ~-2 ~2 ~ ~2 air replace dark_oak_wood
fill ~-2 ~ ~-2 ~2 ~ ~2 air replace stripped_dark_oak_log
fill ~-2 ~ ~-2 ~2 ~ ~2 air replace dark_oak_fence
fill ~-2 ~ ~-2 ~2 ~ ~2 air replace spruce_fence
fill ~2 ~ ~-1 ~2 ~ ~-1 air replace dark_oak_slab
fill ~ ~ ~-1 ~ ~ ~-1 air replace spruce_wood
fill ~1 ~ ~ ~1 ~ ~ air replace spruce_wood
fill ~-1 ~ ~1 ~-1 ~ ~1 air replace spruce_wood[axis=x]



# lower stem blocks
fill ~2 ~-1 ~1 ~2 ~-1 ~1 air replace dark_oak_wood
fill ~2 ~-1 ~1 ~2 ~-1 ~1 grass_block replace spruce_wood
fill ~-1 ~-1 ~-2 ~-1 ~-1 ~-2 air replace dark_oak_wood
fill ~-1 ~-1 ~-2 ~-1 ~-1 ~-2 grass_block replace spruce_wood
fill ~-1 ~-1 ~2 ~-1 ~-1 ~2 air replace dark_oak_wood
fill ~-1 ~-1 ~2 ~-1 ~-1 ~2 grass_block replace spruce_wood
fill ~1 ~-1 ~-2 ~1 ~-1 ~-2 air replace dark_oak_wood
fill ~1 ~-1 ~-2 ~1 ~-1 ~-2 grass_block replace spruce_wood
fill ~ ~-1 ~-1 ~ ~-1 ~-1 air replace dark_oak_wood
fill ~ ~-1 ~1 ~ ~-1 ~1 air replace dark_oak_wood
fill ~ ~-1 ~1 ~ ~-1 ~1 grass_block replace spruce_wood
fill ~-2 ~-1 ~1 ~-2 ~-1 ~1 air replace dark_oak_wood
fill ~-2 ~-1 ~1 ~-2 ~-1 ~1 grass_block replace spruce_wood


# nonbase blocks
fill ~0 ~6 ~2 ~0 ~6 ~2 air replace spruce_fence
fill ~2 ~6 ~0 ~2 ~6 ~0 air replace mangrove_roots
fill ~-2 ~7 ~-1 ~-2 ~7 ~-1 air replace dark_oak_fence
fill ~0 ~7 ~2 ~0 ~7 ~2 air replace mangrove_roots
fill ~-2 ~10 ~0 ~-2 ~10 ~0 air replace spruce_fence
fill ~2 ~10 ~0 ~2 ~10 ~0 air replace mangrove_roots
fill ~-3 ~11 ~0 ~-3 ~11 ~0 air replace mangrove_roots
fill ~-2 ~11 ~0 ~-2 ~11 ~0 air replace dark_oak_fence
fill ~0 ~11 ~2 ~0 ~11 ~2 air replace dark_oak_fence
fill ~0 ~11 ~3 ~0 ~11 ~3 air replace dark_oak_fence
fill ~1 ~11 ~-2 ~1 ~11 ~-2 air replace dark_oak_fence
fill ~-2 ~12 ~0 ~-2 ~12 ~0 air replace spruce_fence
fill ~0 ~12 ~2 ~0 ~12 ~2 air replace dark_oak_fence
fill ~-2 ~13 ~0 ~-2 ~13 ~0 air replace dark_oak_fence
fill ~2 ~13 ~-1 ~2 ~13 ~-1 air replace dark_oak_fence
fill ~-2 ~14 ~1 ~-2 ~14 ~1 air replace dark_oak_fence
fill ~-2 ~15 ~1 ~-2 ~15 ~1 air replace dark_oak_fence
fill ~2 ~16 ~0 ~2 ~16 ~0 air replace dark_oak_fence
fill ~-2 ~17 ~0 ~-2 ~17 ~0 air replace spruce_fence
fill ~0 ~17 ~-2 ~0 ~17 ~-2 air replace dark_oak_fence
fill ~2 ~17 ~0 ~2 ~17 ~0 air replace dark_oak_fence

# kill
kill @s