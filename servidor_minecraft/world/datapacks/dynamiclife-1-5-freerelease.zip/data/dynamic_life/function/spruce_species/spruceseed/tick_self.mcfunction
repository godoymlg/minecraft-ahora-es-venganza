# can germinate
execute if score @s rng matches ..33 run function dynamic_life:spruce_species/spruceseed/actions/germinate_attempt_self

# can spread
execute if score @s rng matches 34..66 run function dynamic_life:spruce_species/spruceseed/actions/spread_self

# can die
execute if score @s rng matches 67.. run kill @s
