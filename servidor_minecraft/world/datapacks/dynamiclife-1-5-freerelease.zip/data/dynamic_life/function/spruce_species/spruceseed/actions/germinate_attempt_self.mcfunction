# create a flower pod if on spruce leaves (gives off the feeling of pinecones)
execute if block ~ ~-1 ~ spruce_leaves run setblock ~ ~ ~ flower_pot

# if air and grass, germinate
execute if block ~ ~ ~ air if block ~ ~-1 ~ grass_block run function dynamic_life:spruce_species/spruceseed/actions/germinate_self
