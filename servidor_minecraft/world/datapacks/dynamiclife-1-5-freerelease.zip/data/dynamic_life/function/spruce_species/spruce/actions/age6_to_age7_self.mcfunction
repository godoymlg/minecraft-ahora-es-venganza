# place age7 struct
place template dynamic_life:spruce/spruce_age7_base ~-1 ~ ~-1

# roots
fill ~ ~ ~2 ~ ~ ~2 dark_oak_fence replace air

fill ~2 ~ ~-1 ~2 ~ ~-1 dark_oak_slab replace air
fill ~-2 ~-1 ~1 ~-2 ~-1 ~1 dark_oak_wood[axis=x] replace air
fill ~-2 ~-1 ~1 ~-2 ~-1 ~1 spruce_wood[axis=x] replace grass_block

# nonbase blocks
fill ~2 ~11 ~-3 ~2 ~11 ~-3 spruce_leaves[persistent=true] replace air
fill ~0 ~12 ~3 ~0 ~12 ~3 dark_oak_leaves[persistent=true] replace air
fill ~1 ~12 ~-2 ~1 ~12 ~-2 spruce_leaves[persistent=true] replace air
fill ~0 ~13 ~2 ~0 ~13 ~2 spruce_leaves[persistent=true] replace dark_oak_fence
fill ~2 ~13 ~0 ~2 ~13 ~0 spruce_leaves[persistent=true] replace dark_oak_leaves
fill ~-3 ~14 ~1 ~-3 ~14 ~1 spruce_leaves[persistent=true] replace air
fill ~0 ~14 ~-2 ~0 ~14 ~-2 spruce_leaves[persistent=true] replace spruce_fence
fill ~-3 ~15 ~-2 ~-3 ~15 ~-2 spruce_leaves[persistent=true] replace air
fill ~-3 ~15 ~-1 ~-3 ~15 ~-1 spruce_leaves[persistent=true] replace air
fill ~2 ~15 ~-2 ~2 ~15 ~-2 spruce_leaves[persistent=true] replace air
fill ~-2 ~16 ~-1 ~-2 ~16 ~-1 spruce_leaves[persistent=true] replace air
fill ~-2 ~16 ~1 ~-2 ~16 ~1 dark_oak_leaves[persistent=true] replace air
fill ~-1 ~16 ~-3 ~-1 ~16 ~-3 spruce_leaves[persistent=true] replace air
fill ~0 ~16 ~-3 ~0 ~16 ~-3 spruce_leaves[persistent=true] replace air
fill ~3 ~16 ~0 ~3 ~16 ~0 spruce_leaves[persistent=true] replace dark_oak_leaves
fill ~-3 ~17 ~0 ~-3 ~17 ~0 spruce_leaves[persistent=true] replace dark_oak_leaves
fill ~-1 ~17 ~-2 ~-1 ~17 ~-2 dark_oak_leaves[persistent=true] replace air
fill ~0 ~17 ~-3 ~0 ~17 ~-3 spruce_leaves[persistent=true] replace air
fill ~0 ~17 ~2 ~0 ~17 ~2 dark_oak_leaves[persistent=true] replace spruce_leaves
fill ~2 ~17 ~1 ~2 ~17 ~1 spruce_leaves[persistent=true] replace air
fill ~3 ~17 ~0 ~3 ~17 ~0 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~18 ~2 ~-2 ~18 ~2 spruce_leaves[persistent=true] replace air
fill ~0 ~18 ~-2 ~0 ~18 ~-2 spruce_leaves[persistent=true] replace air
fill ~1 ~18 ~2 ~1 ~18 ~2 spruce_leaves[persistent=true] replace dark_oak_leaves
fill ~2 ~18 ~0 ~2 ~18 ~0 spruce_leaves[persistent=true] replace air
fill ~2 ~19 ~0 ~2 ~19 ~0 dark_oak_leaves[persistent=true] replace air
fill ~2 ~20 ~-2 ~2 ~20 ~-2 spruce_leaves[persistent=true] replace air
fill ~-2 ~21 ~0 ~-2 ~21 ~0 spruce_leaves[persistent=true] replace dark_oak_leaves
fill ~0 ~21 ~-2 ~0 ~21 ~-2 dark_oak_leaves[persistent=true] replace air
fill ~0 ~22 ~2 ~0 ~22 ~2 spruce_leaves[persistent=true] replace air
fill ~0 ~23 ~-2 ~0 ~23 ~-2 spruce_leaves[persistent=true] replace air
fill ~0 ~11 ~2 ~0 ~11 ~2 dark_oak_fence replace spruce_leaves
fill ~0 ~11 ~3 ~0 ~11 ~3 dark_oak_fence replace air
fill ~1 ~11 ~-2 ~1 ~11 ~-2 dark_oak_fence replace air
fill ~0 ~12 ~2 ~0 ~12 ~2 dark_oak_fence replace dark_oak_leaves
fill ~-2 ~14 ~1 ~-2 ~14 ~1 dark_oak_fence replace air
fill ~-2 ~15 ~1 ~-2 ~15 ~1 dark_oak_fence replace air
fill ~2 ~16 ~0 ~2 ~16 ~0 dark_oak_fence replace spruce_fence
fill ~-2 ~17 ~0 ~-2 ~17 ~0 spruce_fence replace dark_oak_fence
fill ~0 ~17 ~-2 ~0 ~17 ~-2 dark_oak_fence replace dark_oak_leaves
fill ~2 ~17 ~0 ~2 ~17 ~0 dark_oak_fence replace spruce_leaves

# remove "age6"
tag @s remove age6

# add "age7"
tag @s add age7
