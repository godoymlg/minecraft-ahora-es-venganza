# no need to check for space above, won't grow taller
execute as @e[tag=spruce,tag=chosen,tag=age7] at @s run function dynamic_life:spruce_species/spruce/actions/age7_to_age8_self