# check if space above is empty, if so grow
execute at @s[tag=age0] if blocks ~-1 ~1 ~-1 ~1 ~4 ~1 ~ ~100 ~ all run function dynamic_life:spruce_species/spruce/actions/age0_to_age1_self