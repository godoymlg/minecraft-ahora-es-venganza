execute at @s[tag=!age0,tag=!age1] run summon item ~ ~ ~ {Item:{id:"spruce_log"}}
execute at @s[tag=!age0,tag=!age1] run summon item ~ ~ ~ {Item:{id:"spruce_log"}}
execute at @s[tag=!age0,tag=!age1] run summon item ~ ~ ~ {Item:{id:"spruce_log"}}
execute at @s[tag=!age0,tag=!age1] run summon item ~ ~ ~ {Item:{id:"spruce_log"}}
execute at @s[tag=!age0,tag=!age1] run summon item ~ ~ ~ {Item:{id:"spruce_log"}}

function dynamic_life:spruce_species/spruce/actions/die_self