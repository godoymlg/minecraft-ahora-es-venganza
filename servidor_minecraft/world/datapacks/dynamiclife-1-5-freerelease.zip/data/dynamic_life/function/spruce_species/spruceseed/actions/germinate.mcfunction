# tag all seeds with "germinating" if air and grass
execute as @e[tag=chosen,tag=spruceSeed] at @s if block ~ ~ ~ air if block ~ ~-1 ~ grass_block run tag @s add germinating

# place fern at germinating seeds (represents a sapling)
execute at @e[tag=spruceSeed,tag=germinating] run setblock ~ ~ ~ fern

# summon spruce age0
execute at @e[tag=spruceSeed,tag=germinating] run summon marker ~ ~ ~ {Tags:["UE","spruce","age0"]}

# create a flower pod if on spruce leaves (gives off the feeling of pinecones)
execute at @e[tag=chosen,tag=spruceSeed] if block ~ ~-1 ~ spruce_leaves run setblock ~ ~ ~ flower_pot

# kill chosen spruce seed
kill @e[tag=chosen,tag=spruceSeed]
