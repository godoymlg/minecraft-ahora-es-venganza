# check if space above is empty, if so grow
execute at @s[tag=age4] if blocks ~-1 ~21 ~-1 ~1 ~21 ~1 ~ ~100 ~ all run function dynamic_life:spruce_species/spruce/actions/age4_to_age5_self

