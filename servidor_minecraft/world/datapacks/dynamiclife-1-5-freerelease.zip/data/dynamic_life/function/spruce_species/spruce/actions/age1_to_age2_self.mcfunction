# place age2 base struct at "growing"
place template dynamic_life:spruce/spruce_age2_base ~-1 ~ ~-1

# roots
fill ~ ~ ~-1 ~ ~ ~-1 spruce_wood replace air
fill ~ ~-1 ~-1 ~ ~-1 ~-1 dark_oak_wood replace air

fill ~1 ~ ~ ~1 ~ ~ spruce_wood replace air
fill ~-1 ~ ~1 ~-1 ~ ~1 spruce_wood[axis=x] replace air

fill ~2 ~ ~ ~2 ~ ~ dark_oak_fence replace air

fill ~ ~ ~1 ~ ~ ~1 dark_oak_wood replace air
fill ~ ~-1 ~1 ~ ~-1 ~1 dark_oak_wood replace air
fill ~ ~-1 ~1 ~ ~-1 ~1 spruce_wood replace grass_block
fill ~2 ~-1 ~1 ~2 ~-1 ~1 dark_oak_wood[axis=x] replace air
fill ~2 ~-1 ~1 ~2 ~-1 ~1 spruce_wood[axis=x] replace grass_block

# nonbase blocks
fill ~0 ~6 ~3 ~0 ~6 ~3 spruce_leaves[persistent=true] replace air
fill ~0 ~7 ~2 ~0 ~7 ~2 spruce_leaves[persistent=true] replace air
fill ~1 ~7 ~-2 ~1 ~7 ~-2 spruce_leaves[persistent=true] replace air
fill ~2 ~7 ~-2 ~2 ~7 ~-2 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~8 ~-1 ~-2 ~8 ~-1 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~8 ~1 ~-2 ~8 ~1 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~8 ~2 ~-2 ~8 ~2 spruce_leaves[persistent=true] replace air
fill ~0 ~8 ~-2 ~0 ~8 ~-2 dark_oak_leaves[persistent=true] replace air
fill ~1 ~8 ~2 ~1 ~8 ~2 dark_oak_leaves[persistent=true] replace air
fill ~2 ~8 ~0 ~2 ~8 ~0 dark_oak_leaves[persistent=true] replace air
fill ~2 ~8 ~1 ~2 ~8 ~1 spruce_leaves[persistent=true] replace air
fill ~0 ~9 ~2 ~0 ~9 ~2 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~10 ~0 ~-2 ~10 ~0 spruce_leaves[persistent=true] replace air
fill ~0 ~10 ~-2 ~0 ~10 ~-2 spruce_leaves[persistent=true] replace air
fill ~2 ~11 ~0 ~2 ~11 ~0 spruce_leaves[persistent=true] replace air
fill ~0 ~6 ~2 ~0 ~6 ~2 spruce_fence replace air

# remove "age1" from growing
tag @s remove age1

# add "age2" to growing
tag @s add age2

# get rid of excess ferns
fill ~-2 ~-1 ~-2 ~2 ~1 ~2 air replace fern