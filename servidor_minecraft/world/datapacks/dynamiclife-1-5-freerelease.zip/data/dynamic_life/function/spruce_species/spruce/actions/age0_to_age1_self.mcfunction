# place age1 struct
place template dynamic_life:spruce/spruce_age1 ~-1 ~ ~-1

# remove "age0"
tag @s remove age0

# add "age1"
tag @s add age1
