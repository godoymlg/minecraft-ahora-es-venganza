# check if space above is empty, if so grow
execute at @s[tag=age6] if blocks ~-1 ~25 ~-1 ~1 ~26 ~1 ~ ~100 ~ all run function dynamic_life:spruce_species/spruce/actions/age6_to_age7_self