execute if block ~ ~ ~ air run function dynamic_life:spruce_species/spruce/actions/destroyed_by_player_self

# can produce seed 31%
execute if score @s rng matches ..31 run function dynamic_life:spruce_species/spruce/actions/produce_seed_attempt_self

# age 0 dies 6%
execute if score @s[tag=age0] rng matches 32..37 run kill @s[tag=!though]

# age 0 can grow to age 1 6%
execute if score @s rng matches 38..43 run function dynamic_life:spruce_species/spruce/actions/age0_to_age1_attempt_self

# age 1 can grow to age 2 6%
execute if score @s rng matches 44..49 run function dynamic_life:spruce_species/spruce/actions/age1_to_age2_attempt_self

# age 2 can grow to age 3 6%
execute if score @s rng matches 50..55 run function dynamic_life:spruce_species/spruce/actions/age2_to_age3_attempt_self

# age 3 can grow to age 4 6%
execute if score @s rng matches 56..61 run function dynamic_life:spruce_species/spruce/actions/age3_to_age4_attempt_self

# age 4 can grow to age 5 6%
execute if score @s rng matches 62..67 run function dynamic_life:spruce_species/spruce/actions/age4_to_age5_attempt_self

# age 5 can grow to age 6 6%
execute if score @s rng matches 68..73 run function dynamic_life:spruce_species/spruce/actions/age5_to_age6_attempt_self

# age 6 can grow to age 7 6%
execute if score @s rng matches 74..79 run function dynamic_life:spruce_species/spruce/actions/age6_to_age7_attempt_self

# age 7 can grow to age 8 6%
execute if score @s rng matches 80..85 run function dynamic_life:spruce_species/spruce/actions/age7_to_age8_attempt_self

# age 8 can die 12%
execute if score @s rng matches 86..98 run function dynamic_life:spruce_species/spruce/actions/age8_to_death_attempt_self
