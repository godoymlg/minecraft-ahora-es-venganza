# place age6 struct
place template dynamic_life:spruce/spruce_age6_base ~-1 ~ ~-1

# roots
fill ~1 ~-1 ~-2 ~1 ~-1 ~-2 dark_oak_wood replace air
fill ~1 ~-1 ~-2 ~1 ~-1 ~-2 spruce_wood replace grass_block

fill ~-2 ~ ~-1 ~-2 ~ ~-1 spruce_fence replace air

# nonbase blocks
fill ~2 ~10 ~0 ~2 ~10 ~0 spruce_leaves[persistent=true] replace spruce_fence
fill ~-2 ~11 ~2 ~-2 ~11 ~2 spruce_leaves[persistent=true] replace air
fill ~-1 ~11 ~2 ~-1 ~11 ~2 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~12 ~-2 ~-2 ~12 ~-2 spruce_leaves[persistent=true] replace air
fill ~2 ~12 ~0 ~2 ~12 ~0 spruce_leaves[persistent=true] replace spruce_fence
fill ~-2 ~13 ~1 ~-2 ~13 ~1 spruce_leaves[persistent=true] replace dark_oak_leaves
fill ~2 ~13 ~1 ~2 ~13 ~1 dark_oak_leaves[persistent=true] replace air
fill ~0 ~14 ~-3 ~0 ~14 ~-3 spruce_leaves[persistent=true] replace air
fill ~0 ~14 ~3 ~0 ~14 ~3 spruce_leaves[persistent=true] replace air
fill ~-2 ~15 ~2 ~-2 ~15 ~2 spruce_leaves[persistent=true] replace air
fill ~-1 ~15 ~2 ~-1 ~15 ~2 dark_oak_leaves[persistent=true] replace air
fill ~0 ~15 ~-2 ~0 ~15 ~-2 spruce_leaves[persistent=true] replace air
fill ~1 ~15 ~2 ~1 ~15 ~2 spruce_leaves[persistent=true] replace air
fill ~-2 ~16 ~-2 ~-2 ~16 ~-2 dark_oak_leaves[persistent=true] replace air
fill ~-1 ~16 ~-2 ~-1 ~16 ~-2 spruce_leaves[persistent=true] replace air
fill ~0 ~16 ~3 ~0 ~16 ~3 spruce_leaves[persistent=true] replace air
fill ~2 ~16 ~-1 ~2 ~16 ~-1 spruce_leaves[persistent=true] replace air
fill ~3 ~16 ~0 ~3 ~16 ~0 dark_oak_leaves[persistent=true] replace air
fill ~-3 ~17 ~0 ~-3 ~17 ~0 dark_oak_leaves[persistent=true] replace air
fill ~0 ~17 ~2 ~0 ~17 ~2 spruce_leaves[persistent=true] replace air
fill ~1 ~17 ~-2 ~1 ~17 ~-2 dark_oak_leaves[persistent=true] replace air
fill ~2 ~17 ~0 ~2 ~17 ~0 spruce_leaves[persistent=true] replace air
fill ~-2 ~18 ~0 ~-2 ~18 ~0 spruce_leaves[persistent=true] replace air
fill ~1 ~18 ~2 ~1 ~18 ~2 dark_oak_leaves[persistent=true] replace air
fill ~2 ~18 ~1 ~2 ~18 ~1 spruce_leaves[persistent=true] replace air
fill ~-2 ~19 ~1 ~-2 ~19 ~1 dark_oak_leaves[persistent=true] replace air
fill ~0 ~19 ~-2 ~0 ~19 ~-2 spruce_leaves[persistent=true] replace air
fill ~0 ~20 ~2 ~0 ~20 ~2 spruce_leaves[persistent=true] replace air
fill ~-2 ~21 ~0 ~-2 ~21 ~0 dark_oak_leaves[persistent=true] replace air
fill ~0 ~14 ~-2 ~0 ~14 ~-2 spruce_fence replace spruce_leaves
fill ~2 ~16 ~0 ~2 ~16 ~0 spruce_fence replace spruce_leaves
fill ~-2 ~17 ~0 ~-2 ~17 ~0 dark_oak_fence replace air

# remove "age5"
tag @s remove age5

# add "age6"
tag @s add age6