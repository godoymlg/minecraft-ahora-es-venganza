# place age5 struct
place template dynamic_life:spruce/spruce_age5_base ~-1 ~ ~-1

# roots
fill ~-1 ~-1 ~-2 ~-1 ~-1 ~-2 dark_oak_wood replace air
fill ~-1 ~-1 ~-2 ~-1 ~-1 ~-2 spruce_wood replace grass_block
fill ~1 ~ ~-1 ~1 ~ ~-1 dark_oak_wood replace air

fill ~-2 ~ ~ ~-2 ~ ~ spruce_fence replace air

fill ~1 ~ ~1 ~1 ~ ~1 dark_oak_fence replace air

# nonbase blocks
fill ~0 ~8 ~2 ~0 ~8 ~2 spruce_leaves[persistent=true] replace air
fill ~3 ~10 ~1 ~3 ~10 ~1 dark_oak_leaves[persistent=true] replace air
fill ~2 ~11 ~1 ~2 ~11 ~1 spruce_leaves[persistent=true] replace air
fill ~2 ~11 ~2 ~2 ~11 ~2 spruce_leaves[persistent=true] replace air
fill ~-3 ~12 ~0 ~-3 ~12 ~0 spruce_leaves[persistent=true] replace air
fill ~0 ~12 ~-2 ~0 ~12 ~-2 spruce_leaves[persistent=true] replace air
fill ~3 ~12 ~-1 ~3 ~12 ~-1 dark_oak_leaves[persistent=true] replace air
fill ~-3 ~13 ~0 ~-3 ~13 ~0 spruce_leaves[persistent=true] replace air
fill ~-2 ~13 ~-2 ~-2 ~13 ~-2 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~13 ~1 ~-2 ~13 ~1 dark_oak_leaves[persistent=true] replace spruce_leaves
fill ~0 ~13 ~3 ~0 ~13 ~3 spruce_leaves[persistent=true] replace air
fill ~-2 ~14 ~0 ~-2 ~14 ~0 spruce_leaves[persistent=true] replace air
fill ~0 ~14 ~2 ~0 ~14 ~2 spruce_leaves[persistent=true] replace air
fill ~1 ~14 ~-2 ~1 ~14 ~-2 dark_oak_leaves[persistent=true] replace air
fill ~2 ~14 ~-1 ~2 ~14 ~-1 spruce_leaves[persistent=true] replace air
fill ~2 ~14 ~1 ~2 ~14 ~1 spruce_leaves[persistent=true] replace dark_oak_leaves
fill ~2 ~14 ~2 ~2 ~14 ~2 dark_oak_leaves[persistent=true] replace air
fill ~0 ~15 ~2 ~0 ~15 ~2 dark_oak_leaves[persistent=true] replace air
fill ~2 ~15 ~0 ~2 ~15 ~0 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~16 ~0 ~-2 ~16 ~0 spruce_leaves[persistent=true] replace air
fill ~0 ~17 ~-2 ~0 ~17 ~-2 dark_oak_leaves[persistent=true] replace air
fill ~-2 ~12 ~0 ~-2 ~12 ~0 spruce_fence replace spruce_leaves
fill ~-2 ~13 ~0 ~-2 ~13 ~0 dark_oak_fence replace air
fill ~0 ~13 ~2 ~0 ~13 ~2 dark_oak_fence replace air
fill ~2 ~13 ~-1 ~2 ~13 ~-1 dark_oak_fence replace air

# remove "age4"
tag @s remove age4

# add "age5"
tag @s add age5