# can germinate
execute if score $last_random_number rng matches ..33 run function dynamic_life:spruce_species/spruceseed/actions/germinate

# can spread
execute if score $last_random_number rng matches 34..66 run function dynamic_life:spruce_species/spruceseed/actions/spread

# can die
execute if score $last_random_number rng matches 67.. run function dynamic_life:spruce_species/spruceseed/actions/die
