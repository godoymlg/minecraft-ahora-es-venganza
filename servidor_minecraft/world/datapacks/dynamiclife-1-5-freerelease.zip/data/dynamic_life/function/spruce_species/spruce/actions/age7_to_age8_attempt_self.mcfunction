# no need to check for space above, won't grow taller
execute at @s[tag=age7] run function dynamic_life:spruce_species/spruce/actions/age7_to_age8_self