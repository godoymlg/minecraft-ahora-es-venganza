# check if space above is empty, if so grow
execute at @s[tag=age5] if blocks ~-1 ~22 ~-1 ~1 ~24 ~1 ~ ~100 ~ all run function dynamic_life:spruce_species/spruce/actions/age5_to_age6_self