# place age8 struct
place template dynamic_life:spruce/spruce_age8_base ~-1 ~ ~-1

# nonbase blocks
fill ~2 ~6 ~0 ~2 ~6 ~0 mangrove_roots replace air
fill ~0 ~7 ~2 ~0 ~7 ~2 mangrove_roots replace spruce_leaves
fill ~2 ~10 ~0 ~2 ~10 ~0 mangrove_roots replace spruce_leaves
fill ~-3 ~11 ~0 ~-3 ~11 ~0 mangrove_roots replace spruce_leaves
fill ~0 ~6 ~3 ~0 ~6 ~3 air replace spruce_leaves
fill ~-3 ~7 ~-1 ~-3 ~7 ~-1 air replace spruce_leaves
fill ~-2 ~7 ~0 ~-2 ~7 ~0 air replace spruce_leaves
fill ~1 ~7 ~-2 ~1 ~7 ~-2 air replace spruce_leaves
fill ~2 ~7 ~-2 ~2 ~7 ~-2 air replace dark_oak_leaves
fill ~-2 ~8 ~-1 ~-2 ~8 ~-1 air replace spruce_leaves
fill ~-2 ~8 ~1 ~-2 ~8 ~1 air replace dark_oak_leaves
fill ~-2 ~8 ~2 ~-2 ~8 ~2 air replace spruce_leaves
fill ~0 ~8 ~-2 ~0 ~8 ~-2 air replace dark_oak_leaves
fill ~0 ~8 ~2 ~0 ~8 ~2 air replace spruce_leaves
fill ~1 ~8 ~2 ~1 ~8 ~2 air replace dark_oak_leaves
fill ~2 ~8 ~0 ~2 ~8 ~0 air replace spruce_leaves
fill ~2 ~8 ~1 ~2 ~8 ~1 air replace spruce_leaves
fill ~-2 ~9 ~0 ~-2 ~9 ~0 air replace spruce_leaves
fill ~0 ~9 ~-2 ~0 ~9 ~-2 air replace spruce_leaves
fill ~0 ~9 ~2 ~0 ~9 ~2 air replace dark_oak_leaves
fill ~1 ~9 ~2 ~1 ~9 ~2 air replace spruce_leaves
fill ~-3 ~10 ~1 ~-3 ~10 ~1 air replace spruce_leaves
fill ~0 ~10 ~-2 ~0 ~10 ~-2 air replace spruce_leaves
fill ~0 ~10 ~2 ~0 ~10 ~2 air replace spruce_leaves
fill ~1 ~10 ~-2 ~1 ~10 ~-2 air replace spruce_leaves
fill ~1 ~10 ~2 ~1 ~10 ~2 air replace dark_oak_leaves
fill ~3 ~10 ~0 ~3 ~10 ~0 air replace spruce_leaves
fill ~3 ~10 ~1 ~3 ~10 ~1 air replace dark_oak_leaves
fill ~-2 ~11 ~1 ~-2 ~11 ~1 air replace spruce_leaves
fill ~-2 ~11 ~2 ~-2 ~11 ~2 air replace spruce_leaves
fill ~-1 ~11 ~2 ~-1 ~11 ~2 air replace dark_oak_leaves
fill ~0 ~11 ~-2 ~0 ~11 ~-2 air replace spruce_leaves
fill ~2 ~11 ~-3 ~2 ~11 ~-3 air replace spruce_leaves
fill ~2 ~11 ~0 ~2 ~11 ~0 air replace spruce_leaves
fill ~2 ~11 ~1 ~2 ~11 ~1 air replace spruce_leaves
fill ~2 ~11 ~2 ~2 ~11 ~2 air replace spruce_leaves
fill ~-3 ~12 ~0 ~-3 ~12 ~0 air replace spruce_leaves
fill ~-2 ~12 ~-2 ~-2 ~12 ~-2 air replace spruce_leaves
fill ~-2 ~12 ~-1 ~-2 ~12 ~-1 air replace dark_oak_leaves
fill ~-2 ~12 ~1 ~-2 ~12 ~1 air replace dark_oak_leaves
fill ~-1 ~12 ~-2 ~-1 ~12 ~-2 air replace spruce_leaves
fill ~0 ~12 ~-3 ~0 ~12 ~-3 air replace dark_oak_leaves
fill ~0 ~12 ~-2 ~0 ~12 ~-2 air replace spruce_leaves
fill ~0 ~12 ~3 ~0 ~12 ~3 air replace dark_oak_leaves
fill ~1 ~12 ~-3 ~1 ~12 ~-3 air replace spruce_leaves
fill ~1 ~12 ~-2 ~1 ~12 ~-2 air replace spruce_leaves
fill ~2 ~12 ~0 ~2 ~12 ~0 air replace spruce_leaves
fill ~3 ~12 ~-1 ~3 ~12 ~-1 air replace dark_oak_leaves
fill ~3 ~12 ~0 ~3 ~12 ~0 air replace spruce_leaves
fill ~-3 ~13 ~0 ~-3 ~13 ~0 air replace spruce_leaves
fill ~-2 ~13 ~-2 ~-2 ~13 ~-2 air replace dark_oak_leaves
fill ~-2 ~13 ~1 ~-2 ~13 ~1 air replace spruce_leaves
fill ~-1 ~13 ~2 ~-1 ~13 ~2 air replace dark_oak_leaves
fill ~0 ~13 ~2 ~0 ~13 ~2 air replace spruce_leaves
fill ~0 ~13 ~3 ~0 ~13 ~3 air replace spruce_leaves
fill ~1 ~13 ~-2 ~1 ~13 ~-2 air replace dark_oak_leaves
fill ~2 ~13 ~-2 ~2 ~13 ~-2 air replace spruce_leaves
fill ~2 ~13 ~0 ~2 ~13 ~0 air replace spruce_leaves
fill ~2 ~13 ~1 ~2 ~13 ~1 air replace dark_oak_leaves
fill ~-3 ~14 ~1 ~-3 ~14 ~1 air replace spruce_leaves
fill ~-2 ~14 ~0 ~-2 ~14 ~0 air replace spruce_leaves
fill ~0 ~14 ~-3 ~0 ~14 ~-3 air replace spruce_leaves
fill ~0 ~14 ~-2 ~0 ~14 ~-2 air replace spruce_leaves
fill ~0 ~14 ~2 ~0 ~14 ~2 air replace spruce_leaves
fill ~0 ~14 ~3 ~0 ~14 ~3 air replace spruce_leaves
fill ~1 ~14 ~-2 ~1 ~14 ~-2 air replace dark_oak_leaves
fill ~2 ~14 ~-1 ~2 ~14 ~-1 air replace spruce_leaves
fill ~2 ~14 ~1 ~2 ~14 ~1 air replace spruce_leaves
fill ~2 ~14 ~2 ~2 ~14 ~2 air replace dark_oak_leaves
fill ~-3 ~15 ~-2 ~-3 ~15 ~-2 air replace spruce_leaves
fill ~-3 ~15 ~-1 ~-3 ~15 ~-1 air replace spruce_leaves
fill ~-2 ~15 ~0 ~-2 ~15 ~0 air replace dark_oak_leaves
fill ~-2 ~15 ~2 ~-2 ~15 ~2 air replace spruce_leaves
fill ~-1 ~15 ~-2 ~-1 ~15 ~-2 air replace dark_oak_leaves
fill ~-1 ~15 ~2 ~-1 ~15 ~2 air replace dark_oak_leaves
fill ~0 ~15 ~-2 ~0 ~15 ~-2 air replace spruce_leaves
fill ~0 ~15 ~2 ~0 ~15 ~2 air replace dark_oak_leaves
fill ~1 ~15 ~2 ~1 ~15 ~2 air replace spruce_leaves
fill ~2 ~15 ~-2 ~2 ~15 ~-2 air replace spruce_leaves
fill ~2 ~15 ~0 ~2 ~15 ~0 air replace dark_oak_leaves
fill ~-2 ~16 ~-2 ~-2 ~16 ~-2 air replace dark_oak_leaves
fill ~-2 ~16 ~-1 ~-2 ~16 ~-1 air replace spruce_leaves
fill ~-2 ~16 ~0 ~-2 ~16 ~0 air replace spruce_leaves
fill ~-2 ~16 ~1 ~-2 ~16 ~1 air replace dark_oak_leaves
fill ~-1 ~16 ~-3 ~-1 ~16 ~-3 air replace spruce_leaves
fill ~-1 ~16 ~-2 ~-1 ~16 ~-2 air replace spruce_leaves
fill ~0 ~16 ~-3 ~0 ~16 ~-3 air replace spruce_leaves
fill ~0 ~16 ~2 ~0 ~16 ~2 air replace spruce_leaves
fill ~0 ~16 ~3 ~0 ~16 ~3 air replace spruce_leaves
fill ~2 ~16 ~-1 ~2 ~16 ~-1 air replace spruce_leaves
fill ~3 ~16 ~0 ~3 ~16 ~0 air replace spruce_leaves
fill ~-3 ~17 ~0 ~-3 ~17 ~0 air replace spruce_leaves
fill ~-1 ~17 ~-2 ~-1 ~17 ~-2 air replace dark_oak_leaves
fill ~0 ~17 ~-3 ~0 ~17 ~-3 air replace spruce_leaves
fill ~0 ~17 ~2 ~0 ~17 ~2 air replace dark_oak_leaves
fill ~1 ~17 ~-2 ~1 ~17 ~-2 air replace dark_oak_leaves
fill ~2 ~17 ~1 ~2 ~17 ~1 air replace spruce_leaves
fill ~3 ~17 ~0 ~3 ~17 ~0 air replace dark_oak_leaves
fill ~-2 ~18 ~0 ~-2 ~18 ~0 air replace spruce_leaves
fill ~-2 ~18 ~2 ~-2 ~18 ~2 air replace spruce_leaves
fill ~0 ~18 ~-2 ~0 ~18 ~-2 air replace spruce_leaves
fill ~1 ~18 ~2 ~1 ~18 ~2 air replace spruce_leaves
fill ~2 ~18 ~0 ~2 ~18 ~0 air replace spruce_leaves
fill ~2 ~18 ~1 ~2 ~18 ~1 air replace spruce_leaves
fill ~-2 ~19 ~1 ~-2 ~19 ~1 air replace dark_oak_leaves
fill ~0 ~19 ~-2 ~0 ~19 ~-2 air replace spruce_leaves
fill ~2 ~19 ~0 ~2 ~19 ~0 air replace dark_oak_leaves
fill ~0 ~20 ~2 ~0 ~20 ~2 air replace spruce_leaves
fill ~2 ~20 ~-2 ~2 ~20 ~-2 air replace spruce_leaves
fill ~-2 ~21 ~0 ~-2 ~21 ~0 air replace spruce_leaves
fill ~0 ~21 ~-2 ~0 ~21 ~-2 air replace dark_oak_leaves
fill ~0 ~22 ~2 ~0 ~22 ~2 air replace spruce_leaves
fill ~0 ~23 ~-2 ~0 ~23 ~-2 air replace spruce_leaves

# replace pinecones with air
fill ~-3 ~ ~-3 ~3 ~25 ~3 air replace flower_pot

# remove "age7"
tag @s remove age7

# add "age8"
tag @s add age8