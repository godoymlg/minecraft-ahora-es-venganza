# place fern (represents a sapling)
setblock ~ ~ ~ fern

# add spruce tag
tag @s add spruce
tag @s add age0

# remove spruceSeed tag
tag @s remove spruceSeed
