# check if space above is empty, if so grow
execute at @s[tag=age1] at @s if blocks ~-1 ~4 ~-1 ~1 ~15 ~1 ~ ~100 ~ all run function dynamic_life:spruce_species/spruce/actions/age1_to_age2_self