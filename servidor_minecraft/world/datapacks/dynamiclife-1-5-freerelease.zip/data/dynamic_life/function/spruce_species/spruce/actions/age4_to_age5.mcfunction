# check if space above is empty, if so grow
execute as @e[tag=chosen,tag=spruce,tag=age4] at @s if blocks ~-1 ~21 ~-1 ~1 ~21 ~1 ~ ~100 ~ all run function dynamic_life:spruce_species/spruce/actions/age4_to_age5_self

