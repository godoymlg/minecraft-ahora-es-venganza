# check if space above is empty, if so grow
execute at @s[tag=age2] if blocks ~-1 ~16 ~-1 ~1 ~17 ~1 ~ ~100 ~ all run function dynamic_life:spruce_species/spruce/actions/age2_to_age3_self