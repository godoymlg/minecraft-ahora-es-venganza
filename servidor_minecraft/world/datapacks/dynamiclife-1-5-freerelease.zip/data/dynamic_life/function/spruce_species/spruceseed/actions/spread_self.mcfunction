#                                                                                                   did -6
execute at @s run spreadplayers ~ ~ 0 6 false @s