kill @e[tag=temp_block]
execute at @e[tag=lilac,tag=UEslow] run summon block_display ~-0.5 ~ ~-0.5 {block_state:{Name:"magenta_concrete"},Tags:["temp_block"],life:1}
execute at @e[tag=grass,tag=UEslow] run summon block_display ~-0.5 ~ ~-0.5 {block_state:{Name:"lime_concrete"},Tags:["temp_block"],life:1}