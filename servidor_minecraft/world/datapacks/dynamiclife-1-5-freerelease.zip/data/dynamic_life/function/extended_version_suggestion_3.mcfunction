tellraw @p {"color":"gold","text":"If not, that’s totally fine. Your enjoyment alone is already more than I could ask for!"}
