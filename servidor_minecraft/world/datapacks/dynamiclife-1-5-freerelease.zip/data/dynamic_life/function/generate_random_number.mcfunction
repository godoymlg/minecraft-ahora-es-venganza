scoreboard players operation $last_last_random_number rng = $last_random_number rng

# Generate a random number between 1-100 and store it
execute store result score $last_random_number rng run random value 1..100


# Display the number
#tellraw @a [{"text":"Random number: ","color":"gold"},{"score":{"name":"$last_random_number","objective":"rng"}}]