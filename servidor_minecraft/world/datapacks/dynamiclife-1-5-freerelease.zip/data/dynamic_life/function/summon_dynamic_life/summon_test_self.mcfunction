execute if block ~ ~ ~ minecraft:spruce_sapling run function dynamic_life:summon_dynamic_life/summon_spruce_self
execute if block ~ ~ ~ minecraft:lilac run function dynamic_life:summon_dynamic_life/summon_lilac_self
execute if block ~ ~ ~ minecraft:dead_bush run function dynamic_life:summon_dynamic_life/summon_diseasedlilac_self
execute if block ~ ~ ~ minecraft:short_grass run function dynamic_life:summon_dynamic_life/summon_grass_self
execute if block ~ ~ ~ minecraft:short_dry_grass run function dynamic_life:summon_dynamic_life/summon_diseasedgrass_self



