particle minecraft:glow ~ ~ ~ 2 2 2 0.01 50
setblock ~ ~-1 ~ moss_block

summon marker ~ ~ ~ {Tags:["UE", "grass"]}

kill @s
