particle minecraft:glow ~ ~ ~ 2 2 2 0.01 50
setblock ~ ~1 ~ tripwire

summon marker ~ ~ ~ {Tags:["UE", "birch", "age0"]}

advancement grant @p only dynamic_life:birch

kill @s
