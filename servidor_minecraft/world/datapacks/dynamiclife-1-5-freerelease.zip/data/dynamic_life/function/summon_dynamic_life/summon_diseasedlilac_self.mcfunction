particle minecraft:glow ~ ~ ~ 2 2 2 0.01 50

summon marker ~ ~ ~ {Tags:["UE", "diseasedLilac","dormant"]}

kill @s
