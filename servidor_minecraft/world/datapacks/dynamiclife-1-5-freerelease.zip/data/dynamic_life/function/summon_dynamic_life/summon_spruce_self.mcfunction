particle minecraft:glow ~ ~ ~ 2 2 2 0.01 50
setblock ~ ~ ~ fern

summon marker ~ ~ ~ {Tags:["UE", "spruce", "age0","though"]}

advancement grant @p only dynamic_life:spruce

kill @s

scoreboard players set $quick_start_ticks number 100