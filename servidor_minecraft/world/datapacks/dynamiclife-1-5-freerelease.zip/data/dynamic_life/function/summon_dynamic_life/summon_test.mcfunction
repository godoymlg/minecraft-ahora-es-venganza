execute as @e[type=item,nbt={Item:{id:"minecraft:amethyst_shard"}}] at @s run function dynamic_life:summon_dynamic_life/summon_test_self
