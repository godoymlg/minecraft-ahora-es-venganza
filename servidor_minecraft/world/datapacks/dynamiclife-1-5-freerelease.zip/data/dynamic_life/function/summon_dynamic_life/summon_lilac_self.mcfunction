particle minecraft:glow ~ ~ ~ 2 2 2 0.01 50

summon marker ~ ~ ~ {Tags:["UE", "lilac"]}

advancement grant @p only dynamic_life:lilac

kill @s
