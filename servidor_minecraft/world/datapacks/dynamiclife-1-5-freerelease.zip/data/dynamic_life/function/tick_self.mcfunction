
# if slowupdater return false (99% of time)
#execute if entity @s[tag=UEslow] if score $last_random_number rng matches ..99 as @s[tag=UEslow] run return fail

# generate a random number for self
execute store result score @s rng run random value 1..100

#tellraw @a [{"text":"Random number: ","color":"gold"},{"score":{"name":"@s","objective":"rng"}}]

execute as @s[tag=lilac] at @s run function dynamic_life:lilac_species/lilac/tick_self
execute as @s[tag=lilacSeed] run function dynamic_life:lilac_species/lilacseed/tick_self
execute as @s[tag=diseasedLilac] at @s run function dynamic_life:diseasedlilac_species/tick_self
execute as @s[tag=grass] at @s run function dynamic_life:grass_species/grass/tick_self
execute as @s[tag=grassSeed] at @s run function dynamic_life:grass_species/grassseed/tick_self
execute as @s[tag=diseasedGrass] at @s run function dynamic_life:diseasedgrass_species/tick_self
execute as @s[tag=spruce] at @s run function dynamic_life:spruce_species/spruce/tick_self
execute as @s[tag=spruceSeed] at @s run function dynamic_life:spruce_species/spruceseed/tick_self
execute as @s[tag=fox] at @s run function dynamic_life:fox_species/fox/tick_self
