# fox can die
execute if score $last_random_number rng matches ..1 if score $last_last_random_number rng matches ..10 run function dynamic_life:fox_species/actions/die





# fox can eat and breed [foxplosion at 2..51] aprox 180 (too many) foxed at 4..25
execute if score $last_random_number rng matches 4..20 run function dynamic_life:fox_species/actions/eat_and_breed

# fox can eat
execute if score $last_random_number rng matches 54.. run function dynamic_life:fox_species/actions/eat

