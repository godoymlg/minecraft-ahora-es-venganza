# summon foxpoo (don't poo in the air)
execute at @e[tag=chosen,tag=fox] if block ~ ~ ~ air unless block ~ ~-1 ~ air run summon marker ~ ~ ~ {Tags:["UE","foxPoo"]}

# place a button to represent the poo
execute at @e[tag=chosen,tag=fox] if block ~ ~ ~ air unless block ~ ~-1 ~ air run setblock ~ ~ ~ spruce_button[face=floor]