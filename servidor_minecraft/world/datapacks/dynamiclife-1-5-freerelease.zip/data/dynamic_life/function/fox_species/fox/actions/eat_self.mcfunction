# if there's a fern, replace it with air
fill ~ ~ ~ ~ ~ ~ air replace fern