execute store result score @s rng2 run random value 1..100


# name example
execute if score @s rng2 matches 0..13 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'your_patreon_name',Age:-1000}

# in reminiscence of the sweetest dog ever
execute if score @s rng2 matches 14..19 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'Quba',Age:-1000}



# Patrons -------------------------------------------------

# Karo
execute if score @s rng2 matches 20..23 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'Karo',Age:-1000}

# Chinmay Khare     2
execute if score @s rng2 matches 24..33 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'Chinmay Khare',Age:-1000}

# GamingLegends     2
execute if score @s rng2 matches 34..43 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'GamingLegends',Age:-1000}

# Will Layton
execute if score @s rng2 matches 44..49 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'Will Layton',Age:-1000}

# Sasha
execute if score @s rng2 matches 50..54 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'Sasha',Age:-1000}

# Bebber
execute if score @s rng2 matches 55..69 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'Bebber',Age:-1000}

# Fjerns
execute if score @s rng2 matches 70..80 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'Fjerns',Age:-1000}

# Finchy01
execute if score @s rng2 matches 81..85 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'Finchy01',Age:-1000}

# Ko
execute if score @s rng2 matches 86..90 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'Ko',Age:-1000}

# Steggles
execute if score @s rng2 matches 91..95 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'Steggles',Age:-1000}

# gump
execute if score @s rng2 matches 96..100 run summon fox ~ ~ ~ {Tags:["UE","fox"],CustomName:'gump',Age:-1000}

