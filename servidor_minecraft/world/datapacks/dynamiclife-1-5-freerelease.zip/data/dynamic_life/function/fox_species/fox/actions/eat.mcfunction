# if there's a fern, replace it with air
execute at @e[tag=chosen,tag=fox] run fill ~ ~ ~ ~ ~ ~ air replace fern