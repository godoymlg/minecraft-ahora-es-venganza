# summon foxpoo (don't poo in the air)
execute if block ~ ~ ~ air unless block ~ ~-1 ~ air run summon marker ~ ~ ~ {Tags:["UE","foxPoo"]}

# place a button to represent the poo
execute if block ~ ~ ~ air unless block ~ ~-1 ~ air run setblock ~ ~ ~ spruce_button[face=floor]