# if there's a fern, breed
execute if block ~ ~ ~ fern run function dynamic_life:fox_species/fox/actions/summon_named_fox_self
# eat the fern
fill ~ ~ ~ ~ ~ ~ air replace fern