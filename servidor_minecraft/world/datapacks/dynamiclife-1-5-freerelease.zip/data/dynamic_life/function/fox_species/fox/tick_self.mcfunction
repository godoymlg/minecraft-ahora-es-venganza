# fox can die
execute if score @s rng matches ..1 if score $last_last_random_number rng matches ..10 run kill @s


# fox can eat and breed [foxplosion at 2..51] aprox 180 (too many) foxed at 4..25
execute if score @s rng matches 4..20 run function dynamic_life:fox_species/fox/actions/eat_and_breed_self

# fox can eat
execute if score @s rng matches 54.. run function dynamic_life:fox_species/fox/actions/eat_self

