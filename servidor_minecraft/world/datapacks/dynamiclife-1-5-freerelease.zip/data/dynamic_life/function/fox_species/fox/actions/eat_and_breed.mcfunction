# if there's a fern, breed
execute at @e[tag=chosen,tag=fox] if block ~ ~ ~ fern run summon fox ~ ~ ~ {Tags:["UE","fox","chosen"],CustomName:'fern_fox',Age:-1000}

# destroy the fern
execute at @e[tag=chosen,tag=fox] run setblock ~ ~ ~ air