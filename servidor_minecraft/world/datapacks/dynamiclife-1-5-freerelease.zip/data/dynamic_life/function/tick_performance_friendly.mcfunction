execute if score $last_random_number rng matches 1 if score $last_random_number rng matches 1 run scoreboard players remove @a messagesSeen 1

# Get the current tick time (always increasing)
execute store result score $tick rng run time query gametime
# Modulo
scoreboard players operation $tick rng %= global_delay number
# Only tick once in a while (but smear using schedules)
execute unless score $quick_start_ticks number matches 1.. unless score $tick rng matches 0 run return fail
execute if score $quick_start_ticks number matches 1.. run scoreboard players remove $quick_start_ticks number 1

# One tick of dynamic_life, where entities have a chance to update one step.

function dynamic_life:check_player_triggers

gamerule doTileDrops false

# Prepare random number for all species to use
function dynamic_life:generate_random_number

# Summon dynamic life potentially
function dynamic_life:summon_dynamic_life/summon_test

# rare species creation 
execute if score $last_random_number rng matches 1 as @r at @s run function dynamic_life:create_species
function dynamic_life:create_species_fast

# Activate species
execute at @a run execute as @e[tag=UE,distance=..130] run function dynamic_life:tick_self
# Activate slow species
execute if score $last_random_number rng matches 99..100 run execute at @a run execute as @e[tag=UEslow,distance=..130] run function dynamic_life:tick_self

gamerule doTileDrops true

