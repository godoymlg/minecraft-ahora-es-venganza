# place moss at germinating seed
fill ~ ~ ~ ~ ~ ~ moss_carpet replace air

# place mossblock under
#setblock ~ ~-1 ~ moss_block

# add grass tag
tag @s add grass

# remove grassSeed tag
tag @s remove grassSeed