# make neighboring grass grow tall
execute as @e[tag=grass,tag=!tall,distance=..2,limit=1] at @s run function dynamic_life:grass_species/grass/actions/become_tall_self