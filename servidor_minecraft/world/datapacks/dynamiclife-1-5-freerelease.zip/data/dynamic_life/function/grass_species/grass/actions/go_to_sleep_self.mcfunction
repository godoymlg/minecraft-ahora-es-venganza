tag @s remove UE
tag @s add UEslow

#summon block_display ~-0.5 ~ ~-0.5 {block_state:{Name:"minecraft:glass"},Tags:["temp_block"],life:1}

#say going to sleep