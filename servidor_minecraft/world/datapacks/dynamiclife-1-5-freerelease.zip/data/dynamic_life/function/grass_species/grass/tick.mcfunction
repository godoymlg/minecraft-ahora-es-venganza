# tall grass expands (yes I'm aware the actionchance overlaps the produce seed actionchance)
execute if score $last_random_number rng matches ..20 run function dynamic_life:grass_species/grass/actions/tall_grass_expands

# can produce seeds
execute if score $last_random_number rng matches ..87 run function dynamic_life:grass_species/grass/actions/produce_seed

# can die
execute if score $last_random_number rng matches 88..99 run function dynamic_life:grass_species/grass/actions/die

# can become tall
execute if score $last_random_number rng matches 100.. run function dynamic_life:grass_species/grass/actions/become_tall

# stop grass nuke
execute if score $last_random_number rng matches 100.. run function dynamic_life:grass_species/grass/actions/stop_grass_nuke



