# destroy grass block
fill ~ ~ ~ ~ ~ ~ air replace short_grass
fill ~ ~ ~ ~ ~ ~ air replace moss_carpet
fill ~ ~ ~ ~ ~ ~ air replace tall_grass

# set moss block back to grass
fill ~ ~-1 ~ ~ ~-1 ~ grass_block replace moss_block

# kill
kill @s
