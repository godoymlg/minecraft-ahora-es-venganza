# Seed can spread
execute if score @s rng matches ..33 run function dynamic_life:grass_species/grassseed/actions/spread_self

# Seed can die
execute if score @s rng matches 34..60 run kill @s

# Seed can grow short grass
execute if score @s rng matches 61..80 run function dynamic_life:grass_species/grassseed/actions/germinate_shortgras_attempt_self

# Seed can grow moss carpet
execute if score @s rng matches 81.. run function dynamic_life:grass_species/grassseed/actions/germinate_mosscarpet_attempt_self
