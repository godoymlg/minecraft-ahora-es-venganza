# tall grass expands (yes I'm aware the actionchance overlaps the produce seed actionchance)
execute if score @s rng matches ..20 run function dynamic_life:grass_species/grass/actions/tall_grass_expands_attempt_self

# can produce seeds
execute if score @s rng matches ..87 run function dynamic_life:grass_species/grass/actions/produce_seed_self

# can die
execute if score @s rng matches 88..99 run function dynamic_life:grass_species/grass/actions/die_self

# can become tall
# (todo: move to species creation)execute if score @s rng matches 100.. run function dynamic_life:grass_species/grass/actions/become_tall

# stop grass nuke
#execute if score @s rng matches 100.. run function dynamic_life:grass_species/grass/actions/stop_grass_nuke



