# summon grass seed
execute at @e[tag=chosen,tag=grass] run summon marker ~ ~ ~ {Tags:["grassSeed","UE"]}