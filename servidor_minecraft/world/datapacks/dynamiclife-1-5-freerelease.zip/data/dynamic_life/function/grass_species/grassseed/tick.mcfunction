# Seed can spread
execute if score $last_random_number rng matches ..33 run function dynamic_life:grass_species/grassseed/actions/spread

# Seed can die
execute if score $last_random_number rng matches 34..60 run function dynamic_life:grass_species/grassseed/actions/die

# Seed can grow short grass
execute if score $last_random_number rng matches 61..80 run function dynamic_life:grass_species/grassseed/actions/germinate_shortgras

# Seed can grow moss carpet
execute if score $last_random_number rng matches 81.. run function dynamic_life:grass_species/grassseed/actions/germinate_mosscarpet
