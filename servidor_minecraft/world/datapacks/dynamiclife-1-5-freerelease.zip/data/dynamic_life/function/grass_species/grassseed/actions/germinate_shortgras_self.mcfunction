# place grass
setblock ~ ~ ~ minecraft:short_grass

# place mossblock under
setblock ~ ~-1 ~ moss_block

# add grass tag
tag @s add grass

# remove grassSeed tag
tag @s remove grassSeed