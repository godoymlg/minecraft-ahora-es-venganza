# spread
execute as @e[tag=chosen,tag=grassSeed] at @s run function dynamic_life:grass_species/grassseed/actions/spread_self