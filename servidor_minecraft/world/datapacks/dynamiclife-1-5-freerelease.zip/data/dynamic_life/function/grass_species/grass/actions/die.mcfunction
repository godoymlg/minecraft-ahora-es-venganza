# destroy grass block
execute as @e[tag=chosen,tag=grass] at @s run function dynamic_life:grass_species/grass/actions/die_self