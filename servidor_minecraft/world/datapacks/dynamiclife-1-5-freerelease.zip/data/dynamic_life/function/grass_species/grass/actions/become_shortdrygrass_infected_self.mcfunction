# place shortdrygrass
execute if block ~ ~ ~ short_grass run setblock ~ ~ ~ short_dry_grass
# but if it was tall grass, it still become tall dry grass
execute if block ~ ~ ~ tall_grass run setblock ~ ~ ~ tall_dry_grass

# add "diseasedGrass" tag
tag @s add diseasedGrass

# remove grass tag
tag @s remove grass

# add UE tag (in case self is sleeping)
tag @s remove UEslow
tag @s add UE