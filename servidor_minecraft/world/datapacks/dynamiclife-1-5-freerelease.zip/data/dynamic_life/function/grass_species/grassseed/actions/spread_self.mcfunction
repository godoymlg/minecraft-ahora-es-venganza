# spread
spreadplayers ~ ~ 0 3 false @s