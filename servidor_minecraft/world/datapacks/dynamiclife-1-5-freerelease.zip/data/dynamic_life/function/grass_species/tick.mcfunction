function dynamic_life:grass_species/grass/tick
function dynamic_life:grass_species/grassseed/tick