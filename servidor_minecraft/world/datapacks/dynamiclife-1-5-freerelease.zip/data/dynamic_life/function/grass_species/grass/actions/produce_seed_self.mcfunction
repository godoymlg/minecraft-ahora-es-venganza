# summon grass seed
summon marker ~ ~ ~ {Tags:["grassSeed","UE"]}

# small chance to go to sleep for performance reasons
execute if score $last_last_random_number rng matches ..2 if entity @s[tag=produced_once] run function dynamic_life:grass_species/grass/actions/go_to_sleep_self

#tag @s[tag=produced_once, tag=!produced_twice] add produced_twice
tag @s[tag=!produced_once] add produced_once