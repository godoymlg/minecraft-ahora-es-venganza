# replace grass with tall grass
execute if block ~ ~ ~ short_grass run place template dynamic_life:tallgrass/tall_grass

# add tall tag
tag @s add tall

# add UE tag (in case self is sleeping)
tag @s remove UEslow
tag @s add UE
# also remove produced_once tag to reset sleep cycle
tag @s remove produced_once