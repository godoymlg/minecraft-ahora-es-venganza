# only one grass becomes tall rarely
execute as @e[tag=chosen,tag=grass,limit=1] at @s run function dynamic_life:grass_species/grass/actions/become_tall_self