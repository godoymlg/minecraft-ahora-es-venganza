# kill excess grass seeds
kill @e[tag=grassSeed,distance=..2]

# let grass die
execute as @e[tag=grass,distance=..2] at @s run function dynamic_life:grass_species/grass/actions/die_self