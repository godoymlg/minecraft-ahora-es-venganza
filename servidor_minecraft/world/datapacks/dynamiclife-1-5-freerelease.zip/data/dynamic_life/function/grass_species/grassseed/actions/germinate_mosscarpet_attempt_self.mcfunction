# if air and grass, germinate
execute if block ~ ~ ~ air if block ~ ~-1 ~ grass_block run function dynamic_life:grass_species/grassseed/actions/germinate_mosscarpet_self