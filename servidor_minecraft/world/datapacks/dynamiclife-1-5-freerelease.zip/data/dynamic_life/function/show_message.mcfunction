scoreboard players set @s messagesSeen 20

schedule function dynamic_life:extended_version_suggestion_1 15s
