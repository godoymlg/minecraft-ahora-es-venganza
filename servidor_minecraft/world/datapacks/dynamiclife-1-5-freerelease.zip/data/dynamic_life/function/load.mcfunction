# used in time seeded modulo randomness
scoreboard objectives add rng dummy
scoreboard objectives add rng2 dummy
scoreboard objectives add messagesSeen dummy

scoreboard players set $last_random_number rng 100
scoreboard players set $last_last_random_number rng 100


scoreboard objectives add number dummy


# used for max spreadheight of ferns
# scoreboard objectives add spreadheight dummy

scoreboard players set const10 rng 10
scoreboard players set const100 rng 100
scoreboard players set const200 rng 200

execute unless score global_delay number matches 1.. run scoreboard players set global_delay number 200

# trigger commands
scoreboard objectives add delay trigger
scoreboard players enable @a delay



# might seem sketchy, but actually increases performance by getting the job done efficiently in one go
gamerule maxCommandChainLength 1048576
gamerule maxCommandForkCount 1048576

# counts
scoreboard players set $spruce_count rng 999
scoreboard players set $lilac_count rng 999
scoreboard players set $diseased_lilac_count rng 999
scoreboard players set $grass_count rng 999
scoreboard players set $diseased_grass_count rng 999
scoreboard players set $fox_count rng 999


# used for quick start
scoreboard players set $quick_start_ticks number 0
