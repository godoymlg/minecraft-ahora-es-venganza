# grass can grow to tall grass
execute at @a if score $last_random_number rng matches ..2 as @e[tag=grass,limit=5,distance=..100,sort=random] at @s run function dynamic_life:grass_species/grass/actions/become_tall_self

execute if score $last_random_number rng matches 97..100 at @e[type=cow] run function dynamic_life:kill_nearby
execute if score $last_random_number rng matches 97..100 at @e[type=sheep] run function dynamic_life:kill_nearby
execute if score $last_random_number rng matches 97..100 at @e[type=villager] run function dynamic_life:kill_nearby