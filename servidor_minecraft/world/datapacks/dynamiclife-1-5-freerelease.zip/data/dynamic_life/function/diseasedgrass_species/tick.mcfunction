# can infect nearby grass (lichnen)
execute if score $last_random_number rng matches ..25 run function dynamic_life:diseasedgrass_species/actions/infect_lichnen

# can infect nearby grass (warped roots)
execute if score $last_random_number rng matches 26..50 run function dynamic_life:diseasedgrass_species/actions/infect_warpedroots

# can die
execute if score $last_random_number rng matches 51..60 run function dynamic_life:diseasedgrass_species/actions/die

# can become dormant
execute if score $last_random_number rng matches 61 run function dynamic_life:diseasedgrass_species/actions/become_dormant