# destroy block at chosen diseased grass
fill ~ ~ ~ ~ ~ ~ air replace short_dry_grass
fill ~ ~ ~ ~ ~ ~ air replace tall_dry_grass
fill ~ ~ ~ ~ ~ ~ air replace moss_carpet

# set moss block back to grass
fill ~ ~-1 ~ ~ ~-1 ~ grass_block replace moss_block

# kill chosen diseased grass
kill @s