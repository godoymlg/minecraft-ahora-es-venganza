# tag nearby grass infected
execute at @e[tag=chosen,tag=diseasedGrass] run tag @e[tag=grass,distance=..3] add infected

# place lichnen at infected grass
execute at @e[tag=infected,tag=grass] if block ~ ~ ~ short_grass run setblock ~ ~ ~ short_dry_grass

execute at @e[tag=infected,tag=grass] if block ~ ~ ~ tall_grass run setblock ~ ~ ~ tall_dry_grass


# add "diseasedGrass" tag to infected grass
tag @e[tag=infected,tag=grass] add diseasedGrass

# remove grss tag from infected grass
tag @e[tag=infected,tag=grass] remove grass

# remove infected tag from infected diseased grass
tag @e[tag=infected,tag=diseasedGrass] remove infected