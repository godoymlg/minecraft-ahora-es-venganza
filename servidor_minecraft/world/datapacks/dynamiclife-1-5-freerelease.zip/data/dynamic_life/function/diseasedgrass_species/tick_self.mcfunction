# can infect nearby grass (shortdrygrass)
execute if score @s rng matches ..25 run function dynamic_life:diseasedgrass_species/actions/infect_shortdrygrass_self

# can infect nearby grass (talldrygrass)
execute if score @s rng matches 26..50 run function dynamic_life:diseasedgrass_species/actions/infect_talldrygrass_self

# can die
execute if score @s rng matches 51..60 run function dynamic_life:diseasedgrass_species/actions/die_attempt_self

# can become dormant
execute if score @s rng matches 61 run function dynamic_life:diseasedgrass_species/actions/become_dormant_self