# remove all nearby dormant tags                                                                #10
execute at @e[tag=chosen,tag=diseasedGrass] run tag @e[tag=dormant,tag=diseasedGrass,distance=..60] remove dormant

# add 1 dormant tag to nearby diseased grass
execute at @e[tag=chosen,tag=diseasedGrass] run tag @e[tag=diseasedGrass,sort=random,limit=1,distance=..30] add dormant
