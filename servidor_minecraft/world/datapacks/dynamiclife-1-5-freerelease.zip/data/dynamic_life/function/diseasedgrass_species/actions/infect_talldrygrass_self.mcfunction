# tag nearby grass infected
execute as @e[tag=grass,distance=..3] at @s run function dynamic_life:grass_species/grass/actions/become_talldrygrass_infected_self